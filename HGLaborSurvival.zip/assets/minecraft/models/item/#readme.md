### Die Funktionalität ist wie folgt:

 - CustomItems werden beim iron_nugget hinzugefügt, da es sich nur simpel vercraften lässt (was disabled werden kann) und keine weitere Funktionalität besitzt
 - CustomGuis werden mithilfe des chest_minecart hinzugefügt, da sich dies nicht stacken lässt (was verhindert, dass es durch einen Doppelklick auf ein anderes Item kurz wegbewegt wird, was wiederum das Flackern verhindert) und es sehr unwahrscheinlich ist, dass ein Spieler dieses Item auch in seinem Inventar hat
 - Tools werden im besten Fall zu einem equivalenten Vanilla Tool hinzugefügt